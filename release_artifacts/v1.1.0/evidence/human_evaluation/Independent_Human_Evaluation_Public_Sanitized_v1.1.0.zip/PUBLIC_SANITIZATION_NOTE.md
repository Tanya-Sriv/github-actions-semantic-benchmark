# Independent Human Evaluation — Public Sanitized Derivative

The authoritative frozen evaluator workbooks are preserved unchanged in the private/frozen master research archive.

This public derivative removes only Office document-author metadata from `docProps/core.xml`.
Scoring data, blinded response IDs, workflow configurations, model-response text, evaluator judgments, and all other workbook members are unchanged.

No model/provider identities or email addresses are present in the scoring cells.

Use `FROZEN_TO_PUBLIC_HASH_MAPPING.csv` to map each public workbook SHA-256 back to its authoritative frozen-original SHA-256.
