# K–T Supplementary Structured Real-World Extension — Frozen Summary

Freeze date: 2026-09-07

## Final scope

The finalized supplementary case set contains **10 defensible real-world workflow-defect cases** across query families K, L, N, O, Q, S, and T. It is analyzed separately from the primary synthetic benchmark and the historical six-case validation set.

This extension is for **defect-class grounding and robustness**, not prevalence estimation. No representativeness claim is made.

Families M and P contribute **no retained cases** to this freeze. Their complete ordered top-20 replay provenance was not recoverable within the finalization pass, so no screened denominator is claimed for those families. They are not treated as 0/20 negative families.

## Family status

| Family | Retained | Screening status |
|---|---:|---|
| K | 1 | retained case; denominator not claimed |
| L | 1 | retained case; denominator not claimed |
| M | 0 | no retained case; denominator not claimed |
| N | 2 | 20 screened / 18 excluded |
| O | 1 | 20 screened / 19 excluded |
| P | 0 | no retained case; denominator not claimed |
| Q | 1 | 20 screened / 19 excluded |
| R | 0 | 20 screened / 20 excluded; valid negative family |
| S | 3 | 20 screened / 17 excluded |
| T | 1 | 20 screened / 19 excluded |

**Frozen retained total: 10 cases.**

## Taxonomy harmonization

The O015, S017, and S019 cases share the same root cause—direct use of an unavailable `secrets` context in step-level `if` expressions—but remain separate cases because they are independent defects in independent repositories. They are harmonized under **dependency assumptions / context availability**.

K captures false-green path-filter/coverage behavior; L captures cancellation semantics; N captures reusable-workflow resolution/input semantics; Q captures release ref provenance; S013 captures failure propagation; T captures duplicate scheduler authority.

## Freeze rule

No analyzer output is to be inspected or incorporated before this supplementary case manifest is frozen. Subsequent analyzer execution should target the immutable pre-fix workflow state recorded for each retained case.
