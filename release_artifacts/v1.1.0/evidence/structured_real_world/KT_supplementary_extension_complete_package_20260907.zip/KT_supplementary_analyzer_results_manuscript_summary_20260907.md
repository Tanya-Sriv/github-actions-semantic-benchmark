# K–T Supplementary Structured Real-World Extension — Analyzer Results

## Frozen set
The supplementary extension contains 10 retained documented real-world GitHub Actions defects. The set was frozen before analyzer inspection and is analyzed separately from the primary synthetic benchmark and the historical six-case validation set.

## Repair-specific detection results

| Case | Defect class | actionlint 1.7.12 | zizmor 1.28.0 | Poutine 1.1.4 | Union |
|---|---|---:|---:|---:|---:|
| SUP-K-001 | trigger/path-filter behavior; false-green coverage | Miss | Miss | Miss | Miss |
| SUP-L-001 | cross-workflow/concurrency and cancellation semantics | Miss | Miss | Miss | Miss |
| SYS-N004 | dependency assumptions / reusable-workflow resolution | Miss | Miss | Miss | Miss |
| SYS-N007 | shell and pipeline semantics | Miss | Detect | Miss | Detect |
| SYS-O015 | dependency assumptions / context availability | Detect | Miss | Miss | Detect |
| SYS-Q019 | trigger/ref provenance | Miss | Miss | Miss | Miss |
| SYS-S013 | failure propagation | Miss | Miss | Miss | Miss |
| SYS-S017 | dependency assumptions / context availability | Detect | Miss | Miss | Detect |
| SYS-S019 | dependency assumptions / context availability | Detect | Miss | Miss | Detect |
| SYS-T005 | cross-workflow concurrency / duplicate scheduler authority | Miss | Miss | Miss | Miss |

## Aggregate
- actionlint: **3/10 (30%)**
- zizmor: **1/10 (10%)**
- Poutine: **0/10 (0%)**
- Union of the three analyzers: **4/10 (40%)**
- Union misses: **6/10 (60%)**

The three actionlint detections are SYS-O015, SYS-S017, and SYS-S019, where actionlint directly reports that the `secrets` context is unavailable in the step-level `if` expression. Zizmor detects SYS-N007 through its `template-injection` finding on direct reusable-workflow input interpolation. No Poutine finding directly establishes any of the ten repair-specific oracles.

Importantly, raw scanner output contained other warnings on several workflows. Those are not counted as detections unless they identify the documented real-world defect itself. This prevents unrelated security/style findings from inflating repair-specific detection performance.

## Reproducibility
- Controlled all-tool run: `34173774572`
- All-tool harness commit: `0ef531d683a50b91fec56ad11f183fc2b797b089`
- Evidence artifact: `10036553889`
- Evidence artifact digest: `sha256:69962adf2bbd37ec07b5ab47705da96cee8441387e13cb117e3b7253334cff55`
- Corrected Poutine run: `34173841131`
- Corrected Poutine harness commit: `b2521f1cc7855f255019d17a2c6219a15b381d03`
- Corrected Poutine artifact: `10036573998`
- Corrected Poutine artifact digest: `sha256:ae035c3ea3a96acc4e5b41aae8a509a81877b9340c8e0c6a0427ddd21e3d2db6`

The initial Poutine invocation in the all-tool run used `--disable-version-check` in a command position not accepted by the pinned CLI. That Poutine output was discarded and replaced by the corrected Poutine-only run using the environment variable `POUTINE_DISABLE_VERSION_CHECK=1`.
