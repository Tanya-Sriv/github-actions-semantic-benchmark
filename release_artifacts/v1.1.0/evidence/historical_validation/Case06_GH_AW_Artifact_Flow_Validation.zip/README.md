# Case 6 Validation Package

Repository: github/gh-aw
Issue: #29499
Fix PR: #29510

## Defect
The generated activation artifact upload omitted `include-hidden-files: true`.
GitHub's upload-artifact behavior therefore excluded dot-prefixed directories such
as `.github/`, `.claude/`, and `.agents/`. The downstream restoration step
interpreted those directories as absent from the base snapshot and removed them
from the pull-request workspace. The run could still complete successfully while
agent configuration was silently missing.

## Frozen oracle
The activation artifact must preserve required dot-prefixed configuration
directories so downstream restoration does not remove configuration that exists
in the base revision.

## Pair used for static analysis
A representative generated workflow is frozen:

- pre-fix:  github/gh-aw@3f67e54f57fe2dea2474f64a4f2f0492077c3d89
- post-fix: github/gh-aw@654cd6c196269ec8c747e950ecc20ae14e043102
- file: `.github/workflows/ci-doctor.lock.yml`

The compiler-wide repair recompiled 205 generated `.lock.yml` workflows. We use
one exact representative generated workflow to avoid treating 205 mechanically
equivalent generated instances as 205 independent defects.

## Detection rule
A scanner counts as detecting Case 6 only if its finding specifically identifies
the artifact-flow defect described by the oracle. Unrelated security, pinning,
permissions, or other findings do not count.

## Frozen analyzers
- actionlint 1.7.12
- zizmor 1.28.0
- poutine 1.1.4

Run the same analyzer procedure used for Cases 1-5 on `case06/pre` and
`case06/post`, preserving raw output and exit codes.
