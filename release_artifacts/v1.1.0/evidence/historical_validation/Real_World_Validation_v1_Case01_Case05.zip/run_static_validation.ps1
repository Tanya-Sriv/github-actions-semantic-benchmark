﻿$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir = Join-Path $Root "tools"
$ResultsDir = Join-Path $Root "results"
New-Item -ItemType Directory -Force -Path $ToolsDir, $ResultsDir | Out-Null

function Get-ReleaseAsset {
    param(
        [string]$Repo,
        [string]$Tag,
        [string[]]$IncludePatterns,
        [string]$OutDir
    )
    $api = "https://api.github.com/repos/$Repo/releases/tags/$Tag"
    $rel = Invoke-RestMethod -Headers @{ "User-Agent" = "rw-static-validation" } -Uri $api
    $asset = $null
    foreach ($pattern in $IncludePatterns) {
        $asset = $rel.assets | Where-Object { $_.name -match $pattern } | Select-Object -First 1
        if ($asset) { break }
    }
    if (-not $asset) {
        throw "Could not find a matching Windows asset for $Repo $Tag. Available assets: $($rel.assets.name -join ', ')"
    }
    $dest = Join-Path $OutDir $asset.name
    if (-not (Test-Path $dest)) {
        Write-Host "Downloading $($asset.name)..."
        Invoke-WebRequest -Headers @{ "User-Agent" = "rw-static-validation" } -Uri $asset.browser_download_url -OutFile $dest
    }
    return $dest
}

function Expand-ToolArchive {
    param([string]$Archive, [string]$OutDir)
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    if ($Archive -match '\.zip$') {
        Expand-Archive -Force -Path $Archive -DestinationPath $OutDir
    } elseif ($Archive -match '\.(tar\.gz|tgz)$') {
        tar -xzf $Archive -C $OutDir
        if ($LASTEXITCODE -ne 0) { throw "tar failed for $Archive" }
    } else {
        throw "Unsupported archive: $Archive"
    }
}

function Find-Exe {
    param([string]$Name, [string]$SearchRoot)
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $exe = Get-ChildItem -Path $SearchRoot -Recurse -Filter "$Name.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($exe) { return $exe.FullName }
    return $null
}

function Ensure-Tools {
    $actionlint = Find-Exe "actionlint" $ToolsDir
    if (-not $actionlint) {
        $a = Get-ReleaseAsset "rhysd/actionlint" "v1.7.12" @("windows.*x86_64.*\.zip$","windows.*amd64.*\.zip$","windows.*x86_64.*\.tar\.gz$","windows.*amd64.*\.tar\.gz$") $ToolsDir
        Expand-ToolArchive $a (Join-Path $ToolsDir "actionlint-1.7.12")
        $actionlint = Find-Exe "actionlint" $ToolsDir
    }

    $zizmor = Find-Exe "zizmor" $ToolsDir
    if (-not $zizmor) {
        $z = Get-ReleaseAsset "zizmorcore/zizmor" "v1.28.0" @("x86_64.*windows.*\.zip$","windows.*x86_64.*\.zip$","x86_64.*windows.*\.tar\.gz$") $ToolsDir
        Expand-ToolArchive $z (Join-Path $ToolsDir "zizmor-1.28.0")
        $zizmor = Find-Exe "zizmor" $ToolsDir
    }

    $poutine = Find-Exe "poutine" $ToolsDir
    if (-not $poutine) {
        $p = Get-ReleaseAsset "boostsecurityio/poutine" "v1.1.4" @("Windows.*x86_64.*\.zip$","windows.*x86_64.*\.zip$","Windows.*amd64.*\.zip$","windows.*amd64.*\.zip$","Windows.*x86_64.*\.tar\.gz$","windows.*x86_64.*\.tar\.gz$") $ToolsDir
        Expand-ToolArchive $p (Join-Path $ToolsDir "poutine-1.1.4")
        $poutine = Find-Exe "poutine" $ToolsDir
    }

    if (-not $actionlint -or -not $zizmor -or -not $poutine) {
        throw "One or more analyzers could not be located after installation."
    }
    return @{
        actionlint = $actionlint
        zizmor = $zizmor
        poutine = $poutine
    }
}

function Invoke-Captured {
    param(
        [string]$Exe,
        [string[]]$Args,
        [string]$WorkingDirectory,
        [string]$StdoutPath,
        [string]$StderrPath
    )
    Push-Location $WorkingDirectory
    try {
        $old = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        & $Exe @Args 1> $StdoutPath 2> $StderrPath
        $code = $LASTEXITCODE
        $ErrorActionPreference = $old
        return $code
    } finally {
        Pop-Location
    }
}

$tools = Ensure-Tools

# Freeze and verify executable versions in the run record.
$versions = [ordered]@{}
foreach ($k in @("actionlint","zizmor","poutine")) {
    try {
        $versions[$k] = (& $tools[$k] --version 2>&1 | Out-String).Trim()
    } catch {
        $versions[$k] = "version-query-failed: $($_.Exception.Message)"
    }
}
$versions | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $ResultsDir "tool_versions.json")

$expected = @{
    actionlint = "1.7.12"
    zizmor = "1.28.0"
    poutine = "1.1.4"
}
foreach ($k in $expected.Keys) {
    if ($versions[$k] -notmatch [regex]::Escape($expected[$k])) {
        throw "$k version mismatch. Expected $($expected[$k]); got '$($versions[$k])'."
    }
}

$summary = @()

$caseDirs = Get-ChildItem (Join-Path $Root "cases") -Directory | Sort-Object Name
foreach ($case in $caseDirs) {
    foreach ($state in @("pre","post")) {
        $stateDir = Join-Path $case.FullName $state
        $outDir = Join-Path $ResultsDir "$($case.Name)_$state"
        New-Item -ItemType Directory -Force -Path $outDir | Out-Null

        # actionlint: explicit workflow files, preserving exact workflow-local inputs.
        $workflowFiles = Get-ChildItem (Join-Path $stateDir ".github\workflows") -File -Include *.yml,*.yaml
        $alOut = Join-Path $outDir "actionlint.stdout.txt"
        $alErr = Join-Path $outDir "actionlint.stderr.txt"
        $alArgs = @()
        foreach ($wf in $workflowFiles) { $alArgs += $wf.FullName }
        $alCode = Invoke-Captured $tools.actionlint $alArgs $stateDir $alOut $alErr

        # zizmor: local directory, offline audits (CLI default), JSON output.
        $zzOut = Join-Path $outDir "zizmor.json"
        $zzErr = Join-Path $outDir "zizmor.stderr.txt"
        $zzCode = Invoke-Captured $tools.zizmor @("--format=json",".") $stateDir $zzOut $zzErr

        # poutine: local repository-style directory. Disable version-check telemetry.
        $poOut = Join-Path $outDir "poutine.json"
        $poErr = Join-Path $outDir "poutine.stderr.txt"
        $poCode = Invoke-Captured $tools.poutine @("analyze_local",".","--format","json","--disable-version-check") $stateDir $poOut $poErr

        $summary += [pscustomobject]@{
            case = $case.Name
            state = $state
            actionlint_exit = $alCode
            zizmor_exit = $zzCode
            poutine_exit = $poCode
            actionlint_stdout = $alOut
            zizmor_output = $zzOut
            poutine_output = $poOut
        }
    }
}

$summary | Export-Csv -NoTypeInformation -Encoding UTF8 (Join-Path $ResultsDir "run_summary.csv")
$summary | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $ResultsDir "run_summary.json")

Write-Host ""
Write-Host "Finished. Results are under:"
Write-Host "  $ResultsDir"
Write-Host ""
Write-Host "Do not interpret a non-zero exit code as semantic detection."
Write-Host "Detection must be oracle-specific and manually adjudicated."
