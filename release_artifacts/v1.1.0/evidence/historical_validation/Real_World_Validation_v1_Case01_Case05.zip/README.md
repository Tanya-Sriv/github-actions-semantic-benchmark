# Real-World Static Validation Package

This package contains exact pre-fix and fixed GitHub Actions workflow revisions for RW01-RW05.

## Frozen analyzers
- actionlint 1.7.12
- zizmor 1.28.0
- poutine 1.1.4

## Detection rule
A scanner finding counts as detection only when it specifically identifies the documented operational-semantic defect described by the case oracle. Generic security, style, permissions, pinning, or unrelated syntax findings do not count.

## Run
On Windows PowerShell:

    Set-ExecutionPolicy -Scope Process Bypass
    .\run_static_validation.ps1

The runner looks first for the exact analyzer versions on PATH. If missing, it attempts to download the exact tagged Windows release assets from GitHub.

Raw stdout, stderr, exit codes, tool versions, and a run summary are written under `results/`.

## Important interpretation
The package is deliberately workflow-local: each case/state contains the exact affected workflow file(s) under `.github/workflows`. This matches the workflow-focused comparison and prevents unrelated repository-wide findings from being scored as detection. If a scanner reports missing local actions/reusable workflow context, preserve that output but do not score it as semantic detection.

RW03 treats PR #909 and #910 as one defect history; `pre` is the state before #909 and `post` is the successful #910 repair.
